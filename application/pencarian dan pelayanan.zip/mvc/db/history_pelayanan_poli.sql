-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 10, 2020 at 05:04 PM
-- Server version: 10.4.10-MariaDB
-- PHP Version: 7.3.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `lttlkdvr_sibatik`
--

-- --------------------------------------------------------

--
-- Table structure for table `history_pelayanan_poli`
--

CREATE TABLE `history_pelayanan_poli` (
  `id_history` varchar(50) NOT NULL,
  `jenis_pelayanan` varchar(50) NOT NULL,
  `tgl_masuk` datetime NOT NULL,
  `tgl_keluar` datetime DEFAULT NULL,
  `dpjp` varchar(50) NOT NULL,
  `nama_poli` varchar(50) NOT NULL,
  `id_pelayanan` int(50) NOT NULL,
  `id_staff` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `history_pelayanan_poli`
--

INSERT INTO `history_pelayanan_poli` (`id_history`, `jenis_pelayanan`, `tgl_masuk`, `tgl_keluar`, `dpjp`, `nama_poli`, `id_pelayanan`, `id_staff`) VALUES
('poli_4', 'POLI', '2020-06-10 20:24:11', NULL, 'PJ4471IZJ2', 'E00RX703', 34, 'st12');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `history_pelayanan_poli`
--
ALTER TABLE `history_pelayanan_poli`
  ADD PRIMARY KEY (`id_history`),
  ADD UNIQUE KEY `id_history` (`id_history`),
  ADD UNIQUE KEY `id_history_2` (`id_history`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
