-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 10, 2020 at 05:04 PM
-- Server version: 10.4.10-MariaDB
-- PHP Version: 7.3.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `lttlkdvr_sibatik`
--

-- --------------------------------------------------------

--
-- Table structure for table `history_pelayanan_ugd`
--

CREATE TABLE `history_pelayanan_ugd` (
  `id_history` varchar(50) NOT NULL,
  `jenis_pelayanan` varchar(50) NOT NULL,
  `tgl_masuk` datetime NOT NULL,
  `tgl_keluar` datetime DEFAULT NULL,
  `dpjp` varchar(50) NOT NULL,
  `id_pelayanan` int(50) NOT NULL,
  `id_staff` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `history_pelayanan_ugd`
--

INSERT INTO `history_pelayanan_ugd` (`id_history`, `jenis_pelayanan`, `tgl_masuk`, `tgl_keluar`, `dpjp`, `id_pelayanan`, `id_staff`) VALUES
('ugd_3', 'UGD', '2020-06-10 20:11:35', NULL, '4S325ZAEK8', 34, 'st12'),
('ugd_4', 'UGD', '2020-06-10 20:13:14', NULL, '4S325ZAEK8', 34, 'st12');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `history_pelayanan_ugd`
--
ALTER TABLE `history_pelayanan_ugd`
  ADD PRIMARY KEY (`id_history`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
