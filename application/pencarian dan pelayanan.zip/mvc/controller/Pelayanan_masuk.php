<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Pelayanan_masuk extends CI_Controller{

    function __construct()
	{
		parent::__construct();
        date_default_timezone_set('Asia/Jakarta');
        setlocale(LC_ALL, 'id_ID');
        $this->load->model('M_Pelayanan_masuk');
        
    }
    public function index()
    {
        $this->load->view('assets/_header');
        $page_data['page_content']='page_content/Pelayanan_masuk';
        $page_data['poli'] = $this->M_Pelayanan_masuk->getPoli();
        $page_data['kelas'] = $this->M_Pelayanan_masuk->getKelas();
        $page_data['tipe'] = $this->M_Pelayanan_masuk->getNoTidur();
        $page_data['data']=$this->M_Pelayanan_masuk->selectPelayananMasuk();
		$this->load->view('Main',$page_data);
        $this->load->view('assets/_footer');
    
    }

    public function print_gelang($id)
    {
        $data['cetak_gelang']=$this->M_Pelayanan_masuk->getGelangById($id);;
		$this->load->view('print/cetak_gelang', $data);
    }   
    public function print_label($id)
    {
        $data['cetak_label']=$this->M_Pelayanan_masuk->getLabelById($id);;
		$this->load->view('print/cetak_label', $data);
    }   

    
 public function getdata_pelayanan()
 {
     $id_pelayanan=$this->input->post('pelayanan');
     $db=$this->M_Pelayanan_masuk->selectDataPelayananby_id($id_pelayanan);
     if(count($db)>0){
         $db=$db[0];
         $db->status_dt='found';
     }else{
         $db=null;
         $db['status_dt']='not found';
     }
     echo json_encode($db);
     exit;
 }


    public function tampil_pelayanan_masuk(){
        $page_data = $this->M_Pelayanan_masuk->selectPelayananMasuk();
        $out=null;
        for ($i=0; $i < count($page_data); $i++) { 

         $gelang = 	"<a class='btn btn-info btn-icon-anim btn-square' href='Pelayanan_masuk/print_gelang/".$page_data[$i]->id_pelayanan."' ><i class='icon-printer'></i></a>";
         $label= 	"<a class='btn btn-danger btn-icon-anim btn-square' href='Pelayanan_masuk/print_label/".$page_data[$i]->id_pelayanan."' ><i class='icon-printer'></i></a>";
         $tombol = "<button class='btn btn-default btn-icon-anim btn-square' data-toggle='modal' onclick='edit_data_pelayanan(\"" . $page_data[$i]->id_pelayanan . "\")'><i class='fa fa-pencil'></i></button>";
       
        $birthDate = $page_data[$i]->tgl_lahir;
        $date = new DateTime($birthDate);
        $now = new DateTime();
        $interval = $now->diff($date);
        $umur = $interval->y . " Tahun, " . $interval->m . " Bulan";


        $time = strtotime($page_data[$i]->tgl_masuk);
        $date2 = strftime("%A, %d %B %Y ", $time);

        $tgl = strtotime($page_data[$i]->tgl_lahir);
        $date3 = strftime("%A, %d %B %Y ", $tgl);

        $waktu = strftime("%H:%M WIB", $time);

        $no=$i+1;
        $no_rm =  "'" . sprintf('%06d', $page_data[$i]->no_rm);
        $nama=$page_data[$i]->nama;
        $tgl_masuk=$date2;
        $jam_masuk=$waktu;
        $jenis_kelamin=$page_data[$i]->jenis_kelamin;
        $tgl_lahir = $date3;
        $umur=$umur;
        $agama=$page_data[$i]->agama;
        $cara_bayar=$page_data[$i]->cara_bayar;
        $diagnosa=$page_data[$i]->diagnosa;
        $no_sep=$page_data[$i]->no_sep;
    
            $out[$i]=array($no,$tombol,$gelang,$label,$no_rm,$nama,$tgl_masuk,$jam_masuk,$jenis_kelamin,$tgl_lahir,$umur,$agama,$cara_bayar,$diagnosa,$no_sep);
        }
                $page_data['data']=$out;
                echo json_encode($page_data);
    }

    public function getKamar(){
        $kelas = $this->input->post('kelas');
        $data = $this->M_Pelayanan_masuk->getKamar($kelas);
        echo json_encode($data);
    }

    public function tambah_kunjungan()
    {
        $sso_user_data = $this->session->userdata('sso_user_data');
        $username = $sso_user_data->username;
        $id_staff = $this->M_Pelayanan_masuk->getIdStaff($username);
        $id_pelayanan = $this->input->post('id_pelayanan');
        $tgl_masuk= $this->input->post('tgl_masuk');
        $jenis_pelayanan = $this->input->post('jenis_pelayanan');
        $dpjp= $this->input->post('dpjp');
        $nama_poli= $this->input->post('nama_poli');
        $id_kamar= $this->input->post('id_kamar');
        
        if ($jenis_pelayanan == "1") {
            $data_history = array(
                'id_history' => $this->M_Pelayanan_masuk->get_ai_tbl_history_ugd(),
                'jenis_pelayanan' => 'UGD',
                'tgl_masuk' => $tgl_masuk,
                'dpjp' => $dpjp,
                'id_pelayanan' => $id_pelayanan,
                'id_staff' => $id_staff->id_staff,
            );
            $this->M_Pelayanan_masuk->tambah_hitambah_history_ugdstory($data_history);
            $out['status']="success";
       
        } elseif ($jenis_pelayanan == "2") {
            $data_history = array(
                'id_history' => $this->M_Pelayanan_masuk->get_ai_tbl_history_poli(),
                'jenis_pelayanan' => 'POLI',
                'tgl_masuk' => $tgl_masuk,
                'dpjp' => $dpjp,
                'nama_poli' => $this->input->post('nama_poli'),
                'id_pelayanan' => $id_pelayanan,
                'id_staff' => $id_staff->id_staff,
            );
            $this->M_Pelayanan_masuk->tambah_history_poli($data_history);
            $out['status']="success";

        } elseif ($jenis_pelayanan == "3") {
            $out['status']="success";
            $data_history = array(
                'id_history' => $this->M_Pelayanan_masuk->get_ai_tbl_history_ranap(),
                'jenis_pelayanan' => 'RAWAT INAP',
                'tgl_masuk' => $tgl_masuk,
                'dpjp' => $dpjp,
                'id_pelayanan' => $id_pelayanan,
                'id_kamar' => $id_kamar,
                'id_staff' => $id_staff->id_staff,
            );
            $data_kamar = array(
                'id_riwayat' => $this->M_Pelayanan_masuk->get_ai_tbl_idriway(),
                'id_pelayanan' => $id_pelayanan,
                'id_kamar' => $id_kamar,
                'status' => "AKTIF",
                'id_staff' => $id_staff->id_staff,
            );
           
            $this->M_Pelayanan_masuk->tambah_history_ranap($data_history);
    
            $this->M_Pelayanan_masuk->tambah_kamar($data_kamar);
  
            $data_status_kamar = array(
                'status' => "dipakai",
            );
            $this->M_Pelayanan_masuk->ubah_status_kamar($id_kamar, $data_status_kamar);
       
        }
       
        echo json_encode($out);
    }
    public function getDokter(){
        $tipe = $this->input->post('tipe_masuk');
        $poli = $this->input->post('poli');
        if($tipe == 1){
            $spes = "umum";
            $data = $this->M_Pelayanan_masuk->getDokter($spes);
            
        }
        elseif($tipe == 3){
            $data = $this->M_Pelayanan_masuk->getNamaDPJP();
            
        }
        elseif($poli == '111111'){
            $spes = "rehabilitasi";
            $data = $this->M_Pelayanan_masuk->getDokter($spes);
            
        }elseif($poli == '121212'){
            $spes = "umum";
            $data = $this->M_Pelayanan_masuk->getDokter($spes);
            
        }elseif($poli == '146582'){
            $spes = "labor";
            $data = $this->M_Pelayanan_masuk->getDokter($spes);
            
        }
        elseif($poli == '15487956'){
            $spes = "radiologi";
            $data = $this->M_Pelayanan_masuk->getDokter($spes);
            
        }
        elseif($poli == '24QRNLX29R'){
            $spes = "internis";
            $data = $this->M_Pelayanan_masuk->getDokter($spes);
            
        }
        elseif($poli == '2JZ09X4K22'){
            $spes = "kulit";
            $data = $this->M_Pelayanan_masuk->getDokter($spes);
            
        }
        elseif($poli == '6E975PL694'){
            $spes = "rehabilitasi";
            $data = $this->M_Pelayanan_masuk->getDokter($spes);
            
        }
        elseif($poli == 'AX1520L18'){
            $spes = "anestesi";
            $data = $this->M_Pelayanan_masuk->getDokter($spes);
            
        }
        elseif($poli == 'E00RX703'){
            $spes = "anak";
            $data = $this->M_Pelayanan_masuk->getDokter($spes);
            
        }
        elseif($poli == 'HLGI4176K8'){
            $spes = "obgyn";
            $data = $this->M_Pelayanan_masuk->getDokter($spes);
            
        }
        elseif($poli == 'I9NXY5VNQG'){
            $spes = "jantung";
            $data = $this->M_Pelayanan_masuk->getDokter($spes);
            
        }
        elseif($poli == 'MWK205D30K'){
            $spes = "bedah";
            $data = $this->M_Pelayanan_masuk->getDokter($spes);
            
        }
        elseif($poli == 'O782EGU4PR'){
            $spes = "tht";
            $data = $this->M_Pelayanan_masuk->getDokter($spes);
            
        }
        elseif($poli == 'ODI8643C27'){
            $spes = "gigi";
            $data = $this->M_Pelayanan_masuk->getDokter($spes);
            
        }
        elseif($poli == 'RZE28J1098'){
            $spes = "umum";
            $data = $this->M_Pelayanan_masuk->getDokter($spes);
            
        }
        elseif($poli == 'UQ81K76373'){
            $spes = "mata";
            $data = $this->M_Pelayanan_masuk->getDokter($spes);
            
        }
        echo json_encode($data);
    }
    public function getNamaPoli(){
        $data = $this->M_Pelayanan_masuk->getPoli();
        echo json_encode($data);
    }
}