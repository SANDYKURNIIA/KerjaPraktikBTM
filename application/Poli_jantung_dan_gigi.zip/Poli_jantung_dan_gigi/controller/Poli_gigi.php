<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Poli_gigi extends CI_Controller{

    function __construct()
	{
		parent::__construct();
        date_default_timezone_set('Asia/Jakarta');
        setlocale(LC_ALL, 'id_ID');
        $this->load->model('M_Poli_gigi');
    }

    public function index(){
        $this->load->view('assets/_header');
        $page_data['page_content'] = 'page_content/Poli_gigi';
        $page_data['tindakan_poli_gigi']=$this->M_Poli_gigi->selectNamaTindakan();
        $page_data['dokter_gigi']=$this->M_Poli_gigi->selectDokterGigi();
        $this->load->view('Main', $page_data);
        $this->load->view('assets/_footer');
    }
    
    public function tampil_harga(){
        $id_pelayanan = $this->input->post('id_pelayanan');
        $db = $this->M_Poli_gigi->harga_total($id_pelayanan);
        if(count($db)>0){
         $db=$db[0];
         $db->status_dt='found';
     }else{
         $db=null;
         $db['status_dt']='not found';
     }
     echo json_encode($db);
     exit;
    }
        public function tampil_pasien_gigi(){
        $page_data = $this->M_Poli_gigi->selectDataPasiengigi();
         $out=null;
        for ($i=0; $i < count($page_data); $i++) { 
            $edit =
            "<button class='btn btn-success btn-icon-anim btn-square' data-toggle='modal' onclick='edit_data_tindakan(\"" . $page_data[$i]->id_pelayanan ."\",\"". $page_data[$i]->id_history . "\")'><i class='icon-rocket'></i></button>";

         $time = strtotime($page_data[$i]->tgl_masuk);
         $date2 = strftime("%A, %d %B %Y ", $time);
         $waktu = strftime("%H:%M WIB", $time);
         $tgl = strtotime($page_data[$i]->tgl_lahir);
         $date3 = strftime("%A, %d %B %Y ", $tgl);
         $birthDate = $page_data[$i]->tgl_lahir;
         $date = new DateTime($birthDate);
         $now = new DateTime();
         $interval = $now->diff($date);
         $umur = $interval->y . " Tahun, " . $interval->m . " Bulan";

        $no=$i+1;
        $tgl_masuk=$date2;
        $jam_masuk=$waktu;
        $no_rm =  "" . sprintf('%06d', $page_data[$i]->no_rm);
        $nama=$page_data[$i]->nama;         
        $jenis_kelamin=$page_data[$i]->jenis_kelamin;
        $tgl_lahir=$date3;
        $umur=$umur;
        $cara_masuk = $page_data[$i]->jenis_pelayanan;
        $ruang = $page_data[$i]->poli; 
        $cara_bayar = $page_data[$i]->cara_bayar;
        $diagnosa= $page_data[$i]->diagnosa;
        $dokter = $page_data[$i]->nama_dokter;

            $out[$i]=array($no,$edit,$tgl_masuk,$jam_masuk,$no_rm,$nama,$jenis_kelamin,$tgl_lahir,$umur,$cara_masuk,$ruang,$cara_bayar,$diagnosa,$dokter);
        }
        if ($out == null) {
            echo '{"data":""}';
            exit;
        } else {
            $page_data['data'] = $out;
            echo json_encode($page_data);
            exit;
        }
    }

    public function getdata_gigi(){
     $id_pelayanan=$this->input->post('pelayanan');
     $id_history=$this->input->post('history');
     $db=$this->M_Poli_gigi->selectDataPasiengigiby_id($id_pelayanan,$id_history);
     if(count($db)>0){
         $db=$db[0];
         $db->status_dt='found';
     }else{
         $db=null;
         $db['status_dt']='not found';
     }
     echo json_encode($db);
     exit;
    }

    public function insert_tindakan()
    {
        $data = $this->session->userdata('data_auth');

        $id_pelayanan = $this->input->post('idPelayanan');

        $id_tindakan_poli_gigi = uniqid();
        $id_list_tindakan_gigi = $this->input->post('id_list_tindakan_gigi');

        $harga = $this->input->post('harga');
        $frek = $this->input->post('frek');
        $total = $this->input->post('total');
        $id_dokter = $this->input->post('dokter');
        $tgl =  date("Y-m-d h:i:sa");
        $staff = $data->id_staff;

        $page_data = array(
            'id_tindakan_poli_gigi' => $id_tindakan_poli_gigi,
            'id_pelayanan' => $id_pelayanan,
            'id_list_tindakan' => $id_list_tindakan_gigi,
            'harga' => $harga,
            'frek' => $frek,
            'tanggal' => $tgl,
            'total' => $total,
            'id_dokter' => $id_dokter,
            'id_staff' => $staff,
        );
        $this->M_Poli_gigi->insert_tindakan($page_data, 'tindakan_poli_gigi');
        $out['status'] = "success";
        echo json_encode($out);
    }

     public function tampil_list_tindakan()
    {
        $id_pelayanan = $this->input->post('id_pelayanan');
        $page_data = $this->M_Poli_gigi->selectDataTindakanByIdPel($id_pelayanan);

        $out = null;
        
        for ($i = 0; $i < count($page_data); $i++) {
            // 
            $tombol =   "<button class='btn btn-danger btn-icon-anim btn-square' data-toggle='modal' onclick='hapus_data_tindakan(\"" . $page_data[$i]->id_tindakan_poli_gigi . "\",\"" . $id_pelayanan . "\",\"" .$page_data[$i]->nama_tindakan.  "\")' '><i class='fa fa-trash '></i></button>";

            $no = $i+1;
            $nama_tindakan = $page_data[$i]->nama_tindakan;
            $harga = "Rp " . number_format($page_data[$i]->harga, 0, ',', '.');
            $frek = $page_data[$i]->frek;
            $total = "Rp " . number_format($page_data[$i]->total, 0, ',', '.');
            $nama_dokter = $page_data[$i]->nama_dokter;
            $nama_staff = $page_data[$i]->nama_staff;
            $tombol = $tombol;

            $out[$i] = array($no, $nama_tindakan, $harga, $frek, $total, $nama_dokter, $nama_staff, $tombol);
        }
        if ($out == null) {
            echo '{"data":""}';
            exit;
        } else {
            $page_data['data'] = $out;
            echo json_encode($page_data);
            exit;
        }
    }


    public function tampil_total_harga()
    {
        $id_pelayanan = $this->input->post('id_pelayanan');
        $page_data = $this->M_Poli_gigi->Total_Harga_Byid($id_pelayanan);
        $out = null;
 
        for ($i = 0; $i < count($page_data); $i++) {
            $id_tindakan_igd  = "Rp. " . number_format($page_data[$i]->total, 0, ',', '.');
            $out[$i] = array($id_tindakan_igd);
        }
        if ($out == null) {
            echo '{"data":""}';
            exit;
        } else {
            $page_data['data'] = $out;
            echo json_encode($page_data);
            exit;
        }
    }


     function hapus_data_tindakan()
    {
        $id_tindakan_poli_gigi = $this->input->post('id_tindakan_poli_gigi');
        $this->M_Poli_gigi->delete_tindakan($id_tindakan_poli_gigi);
        $out['status'] = "success";
        echo json_encode($out);
    }
    
    // Antrian
    public function antrian(){
        $this->load->view('assets/_header');
        $page_data['page_content'] = 'page_content/Antrian_gigi.php';
        $page_data['count_data'] = $this->M_Poli_gigi->selectCountData();
        $page_data['antrian_data'] = $this->M_Poli_gigi->getAntrianPoli();
        $this->load->view('Main', $page_data);
        $this->load->view('assets/_footer');
    }

    public function tampilAntrian(){
        $data = $this->M_Poli_gigi->selectAntrian();
        $out=null;
        for ($i=0; $i < count($data); $i++) { 
         if ($data[$i]->status == 0) {
            $status =
            "<span class='label label-success capitalize-font inline-block'>ANTRI</span>";
            $skip = "<button class='btn btn-danger btn-icon-anim btn-square' data-toggle='modal'  onclick='skip_data(\"" . $data[$i]->id_antrian . "\")' '><i class='icon-close'></i></button>";
        } else {
            $status =
            "<span class='label label-danger capitalize-font inline-block'>SKIP</span>";
            $skip ="";
        }
        
        $panggil = "<button class='btn btn-success btn-icon-anim btn-square' data-toggle='modal'  onclick='playTableSuara(\"" . "l" . $data[$i]->no_antri. "\",\"" .$data[$i]->poli. "\",\"" .$data[$i]->nama. "\")' '><i class='icon-control-play'></i></button>";

        $time = strtotime($data[$i]->jam);
        $waktu = strftime("%H:%M WIB", $time);

        $id_antrian=$data[$i]->id_antrian;
        $no_rm= $data[$i]->no_rm;
        $nama= $data[$i]->nama;
        $cara_bayar=$data[$i]->cara_bayar;
        $no_antri = $data[$i]->no_antri;
        $status=$status;
        $jam_masuk=$waktu;
        $skip=$skip;
        $panggil=$panggil;

        $out[$i]=array($id_antrian,$no_antri,$jam_masuk,$no_rm,$nama,$cara_bayar, $status,$skip,$panggil);
        }
        if($out==null){
            echo '{"data":""}';
            exit;
         }else{
            $data['data']=$out;
            echo json_encode($data);
            exit;
        }
    }

    
    public function updateskip(){
        $id_antrian = $this->input->post('id_antrian');
        $status = '1';
    
        $data = array(
            'status' => $status
        );

        $where = array(
            'id_antrian' => $id_antrian
        );
    
        $this->M_Poli_gigi->updateskip($where, $data,'antrian_poli');
   
        $out['status']="success";
        echo json_encode($out);
    }

    public function updatenext(){
        $id_antrian = $this->input->post('id_antrian');

        $status = '2';

        $data = array(
            'status' => $status
        );

        $where = array(
            'id_antrian' => $id_antrian
        );

        $this->M_Poli_gigi->updatenext($where, $data,'antrian_poli');
        $out['status']="success";
        echo json_encode($out);
    }


    public function playSuara(){
        $nomor =$this->input->post("nomor");
        $nama =$this->input->post("nama");

        $tipe = 'POLI';
        $poli = 'GIGI';

        $data = array(
            'no' => $nomor,
            'tipe' => $tipe,
            'poli' => $poli,
            'nama' => $nama,
            );

        $this->M_Poli_gigi->insertplaySuara($data,'temp_panggil_antrian');
        $out['status']="success";
        echo json_encode($out);
    }

}
