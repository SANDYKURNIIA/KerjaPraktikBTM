<?php

class M_Poli_gigi extends CI_Model
{
    public function selectDataPasienGigi()
    {
        $this->db->from('v_pasien_gigi');
        return $this->db->get()->result();
    }
    public function selectDataPasienGigiby_id($id_pelayanan, $id_history)
    {
        $this->db->where(array('id_pelayanan' => $id_pelayanan, 'id_history' => $id_history));
        $this->db->from('v_pasien_gigi');
        return $this->db->get()->result();
    }
    public function selectNamaTindakan()
    {
        $this->db->select('nama nama_tindakan, id_tindakan_gigi, harga_jasa, harga_sarana');
        $this->db->where('status', 'AKTIF');
        $this->db->from('list_tindakan_poli_gigi');
        $this->db->order_by('nama_tindakan');
        return $this->db->get()->result_array();
    }
    public function selectDokterGigi()
    {
        $this->db->select('nama, id_dokter');
        $this->db->where('dokter_spes', 'gigi');
        $this->db->where('status', 'aktif');
        $this->db->from('dokter');
        $this->db->order_by('nama');
        return $this->db->get()->result();
    }
    public function insert_tindakan($page_data, $table)
    {
        $this->db->insert($table, $page_data);
    }
    public function selectDataTindakanByIdPel($id_pelayanan)
    {
        $this->db->select('*');
        $this->db->from('v_tindakan_poli_gigi');
        $this->db->where('id_pelayanan', $id_pelayanan);
        return $this->db->get()->result();
    }
    public function delete_tindakan($id_tindakan_gigi)
    {
        $this->db->delete('tindakan_poli_gigi', array('id_tindakan_poli_gigi' => $id_tindakan_gigi));
    }
    public function harga_total($idPelayanan)
    {
        $this->db->select('SUM(total) as total');
        $this->db->from('tindakan_poli_gigi');
        $this->db->where('id_pelayanan', $idPelayanan);
        return $this->db->get()->row()->total;
    }
    public function Total_Harga_Byid($id_pelayanan)
    {
        $this->db->select_sum('total');
        $this->db->from('v_tindakan_poli_gigi');
        $this->db->where('id_pelayanan', $id_pelayanan);
        return $this->db->get()->result();
    }

    //  Antrian

    public function selectAntrian()
    {
        $tanggal = date('Y-m-d');
        $hasil = $this->db->query("SELECT a.*, p.nama,c.nama cara_bayar,p.no_rm,pel.id_pelayanan 
    FROM antrian_poli a, pelayanan pel, pasien p, cara_bayar c 
    WHERE a.poli='ODI8643C27' and a.tanggal='$tanggal' and a.status!=2 and p.no_rm=pel.id_pasien and c.id_cara_bayar=pel.cara_bayar and a.id_pelayanan=pel.id_pelayanan and a.jenis_antrian='ONLINE' 
    UNION all 
    SELECT a.*, p.nama,c.nama cara_bayar,p.no_rm,pel.id_pelayanan FROM antrian_poli a, pelayanan pel, pasien p, cara_bayar c 
    WHERE a.poli='ODI8643C27' and a.tanggal='$tanggal' and a.status!=2 and p.no_rm=pel.id_pasien and c.id_cara_bayar=pel.cara_bayar and a.id_pelayanan=pel.id_pelayanan and a.jenis_antrian='LANGSUNG' order by status ,no_antri");
        return $hasil->result();
    }

    public function updateskip($where, $data, $table)
    {
        $this->db->where($where);
        $this->db->update($table, $data);
    }

    public function updatenext($where, $data, $table)
    {
        $this->db->where($where);
        $this->db->update($table, $data);
    }

    public function insertplaySuara($data, $table)
    {
        $this->db->insert($table, $data);
    }

    public function selectCountData()
    {
        $tanggal = date('Y-m-d');
        $this->db->select('poli, count(poli) as jumlah');
        $this->db->where('poli', 'ODI8643C27');
        $this->db->where_Not_In('status', '2');
        $this->db->like('tanggal', $tanggal);
        return $this->db->get('antrian_poli')->row_array();
    }

    public function getAntrianPoli()
    {
        $tanggal = date('Y-m-d');
        $hasil = $this->db->query("SELECT a.*, p.nama,c.nama cara_bayar,p.no_rm,pel.id_pelayanan 
    FROM antrian_poli a, pelayanan pel, pasien p, cara_bayar c 
    WHERE a.poli='ODI8643C27' and a.tanggal='$tanggal' and a.status!=2 and p.no_rm=pel.id_pasien and c.id_cara_bayar=pel.cara_bayar and a.id_pelayanan=pel.id_pelayanan and a.jenis_antrian='ONLINE' 
    UNION all 
    SELECT a.*, p.nama,c.nama cara_bayar,p.no_rm,pel.id_pelayanan FROM antrian_poli a, pelayanan pel, pasien p, cara_bayar c 
    WHERE a.poli='ODI8643C27' and a.tanggal='$tanggal' and a.status!=2 and p.no_rm=pel.id_pasien and c.id_cara_bayar=pel.cara_bayar and a.id_pelayanan=pel.id_pelayanan and a.jenis_antrian='LANGSUNG' order by status ,no_antri");
        return $hasil->row_array();
    }
}
