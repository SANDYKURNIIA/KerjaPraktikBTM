<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Logistik_farmasi extends CI_Controller
{
    function __construct()
    {
        parent::__construct();
        date_default_timezone_set('Asia/Jakarta');
        $this->load->model('M_Logistik_farmasi');
    }

    // Laporan mutasi
    public function Laporan_mutasi()
    {
        $this->load->view('assets/_header');
        $page_data['page_content'] = 'page_content/Laporan_mutasi_farmasi';
        $this->load->view('Main', $page_data);
        $this->load->view('assets/_footer');
    }

    public function Tampil_laporan_mutasi()
    {
        $page_data = $this->M_Logistik_farmasi->selectLaporanmutasiFarmasi();

        $out = null;
        for ($i = 0; $i < count($page_data); $i++) {
            $no = $i + 1;
            $jenis = $page_data[$i]->ket;
            $nama = $page_data[$i]->nama;
            $tipe = $page_data[$i]->tipe;
            $jml_terima = $page_data[$i]->jml_terima;
            $time = strtotime($page_data[$i]->tgl_res);
            $tgl = strftime("%A, %d %B %Y", $time);
            $waktu = strftime("%H:%M WIB", $time);
            $out[$i] = array($no, $jenis, $nama, $tipe, $jml_terima, $tgl, $waktu);
        }

        if ($out == null) {
            echo '{"data":""}';
            exit;
        } else {
            $page_data['data'] = $out;
            echo json_encode($page_data);
            exit;
        }
    }

    public function Tampil_Rangelaporan_mutasi()
    {

        $mulai = $this->input->post('mulai');
        $akhir = $this->input->post('akhir');

        $page_data = $this->M_Logistik_farmasi->selectRangeLaporanmutasiFarmasi($mulai, $akhir);

        $out = null;
        for ($i = 0; $i < count($page_data); $i++) {
            $no = $i + 1;
            $jenis = $page_data[$i]->ket;
            $nama = $page_data[$i]->nama;
            $tipe = $page_data[$i]->tipe;
            $jml_terima = $page_data[$i]->jml_terima;
            $time = strtotime($page_data[$i]->tgl_res);
            $tgl = strftime("%A, %d %B %Y", $time);
            $waktu = strftime("%H:%M WIB", $time);
            $out[$i] = array($no, $jenis, $nama, $tipe, $jml_terima, $tgl, $waktu);
        }

        if ($out == null) {
            echo '{"data":""}';
            exit;
        } else {
            $page_data['data'] = $out;
            echo json_encode($page_data);
            exit;
        }
    }


    // End

    //Pengeluaran Obat
    public function Pengeluaran_obat()
    {
        $this->load->view('assets/_header');
        $page_data['page_content'] = 'page_content/Laporan_pengeluaran_obat';
        $this->load->view('Main', $page_data);
        $this->load->view('assets/_footer');
    }

    public function Tampil_pengeluaran_obat()
    {
        $page_data = $this->M_Logistik_farmasi->selectPengeluaranObat();

        $out = null;
        for ($i = 0; $i < count($page_data); $i++) {
            $no = $i + 1;
            $nama = $page_data[$i]->nama;
            $stok = $page_data[$i]->stok;
            $out[$i] = array($no, $nama, $stok);
        }

        if ($out == null) {
            echo '{"data":""}';
            exit;
        } else {
            $page_data['data'] = $out;
            echo json_encode($page_data);
            exit;
        }
    }

    public function Tampil_Range_Pengeluaran_obat()
    {

        $mulai = $this->input->post('mulai');
        $akhir = $this->input->post('akhir');

        $page_data = $this->M_Logistik_farmasi->selectRangePengeluaranObat($mulai, $akhir);

        $out = null;
        for ($i = 0; $i < count($page_data); $i++) {
            $no = $i + 1;
            $nama = $page_data[$i]->nama;
            $stok = $page_data[$i]->stok;
            $out[$i] = array($no, $nama, $stok);
        }

        if ($out == null) {
            echo '{"data":""}';
            exit;
        } else {
            $page_data['data'] = $out;
            echo json_encode($page_data);
            exit;
        }
    }

    //END

    
    //Laporan Pembelian
    public function Laporan_pembelian()
    {
        $this->load->view('assets/_header');
        $page_data['page_content'] = 'page_content/Laporan_pembelian_farmasi';
        $this->load->view('Main', $page_data);
        $this->load->view('assets/_footer');
    }

    public function Tampil_laporan_pembelian()
    {
        $page_data = $this->M_Logistik_farmasi->selectLaporanPembelian();

        $out = null;
        for ($i = 0; $i < count($page_data); $i++) {
            $no = " ". $page_data[$i]->no_faktur;
            $nama_produsen = $page_data[$i]->nama_produsen;
            $nama = $page_data[$i]->nama;
            $id_prod_obat = $page_data[$i]->id_prod_obat;
            $tipe = $page_data[$i]->tipe;
            $golongan_obat = $page_data[$i]->golongan_obat;
            $frek = $page_data[$i]->frek;
            $harga_beli = $page_data[$i]->harga_beli;
            $diskon = $page_data[$i]->diskon;
            $disc = $diskon/100 * $harga_beli*$frek;
            $ppn = $page_data[$i]->ppn;
            $total = $harga_beli*$frek;
            $time = strtotime($page_data[$i]->tgl_masuk);
            $tgl = strftime("%A, %d %B %Y", $time);
            $out[$i] = array($no, $nama_produsen, $nama, $id_prod_obat, $tipe, $golongan_obat, $frek, $harga_beli, $diskon, $disc, $ppn, $total, $tgl);
        }

        if ($out == null) {
            echo '{"data":""}';
            exit;
        } else {
            $page_data['data'] = $out;
            echo json_encode($page_data);
            exit;
        }
    }

    public function Tampil_Range_Pembelian()
    {

        $mulai = $this->input->post('mulai');
        $akhir = $this->input->post('akhir');

        $page_data = $this->M_Logistik_farmasi->selectRangeLaporanPembelian($mulai, $akhir);

        $out = null;
        for ($i = 0; $i < count($page_data); $i++) {
            $no = " ". $page_data[$i]->no_faktur;
            $nama_produsen = $page_data[$i]->nama_produsen;
            $nama = $page_data[$i]->nama;
            $id_prod_obat = $page_data[$i]->id_prod_obat;
            $tipe = $page_data[$i]->tipe;
            $golongan_obat = $page_data[$i]->golongan_obat;
            $frek = $page_data[$i]->frek;
            $harga_beli = $page_data[$i]->harga_beli;
            $diskon = $page_data[$i]->diskon;
            $disc = $diskon/100 * $harga_beli*$frek;
            $ppn = $page_data[$i]->ppn;
            $total = $harga_beli*$frek;
            $time = strtotime($page_data[$i]->tgl_masuk);
            $tgl = strftime("%A, %d %B %Y", $time);
            $out[$i] = array($no, $nama_produsen, $nama, $id_prod_obat, $tipe, $golongan_obat, $frek,  $frek,'', $harga_beli, $diskon, $disc, $ppn, $total, $tgl);
        }

        if ($out == null) {
            echo '{"data":""}';
            exit;
        } else {
            $page_data['data'] = $out;
            echo json_encode($page_data);
            exit;
        }
    }

    //END

    //Laporan Pembelian Obat Kundur
    public function Laporan_po_kundur()
    {
        $this->load->view('assets/_header');
        $page_data['page_content'] = 'page_content/Laporan_po_kundur';
        $this->load->view('Main', $page_data);
        $this->load->view('assets/_footer');
    }

    public function Tampil_laporan_po_kundur()
    {
        $page_data = $this->M_Logistik_farmasi->selectLaporanPoKundur();

        $out = null;
        for ($i = 0; $i < count($page_data); $i++) {
            $button = "<div class='btn btn-success btn-icon-anim btn-square' onclick='tampilPermintaanObat(\"" . $page_data[$i]->id_req ."\")'><i class='icon-pencil'></i></div>";
            
            $time = strtotime($page_data[$i]->tanggal);
            $tgl = strftime("%A, %d %B %Y", $time);
            $waktu = strftime("%H:%M WIB", $time);

            $no = $i + 1;
            $status = $page_data[$i]->status;
            
            $out[$i] = array($no, $button, $tgl, $waktu, $status);
        }

        if ($out == null) {
            echo '{"data":""}';
            exit;
        } else {
            $page_data['data'] = $out;
            echo json_encode($page_data);
            exit;
        }
    }
    
    public function tampil_list_tindakan(){
        $id_req = $this->input->post('id_req');
        $page_data = $this->M_Logistik_farmasi->selectTindakanById($id_req);

        $out = null;
        for ($i = 0; $i < count($page_data); $i++) {
            $no = $i + 1;
            $nama = $page_data[$i]->nama;
            $tipe = $page_data[$i]->tipe;
            $jml_terima = $page_data[$i]->jml_terima;
            $harga_cost = $page_data[$i]->harga_cost;
            $total = $harga_cost*$jml_terima;
            $out[$i] = array($no, $nama, $tipe, $jml_terima, $harga_cost, $total);
        }

        if ($out == null) {
            echo '{"data":""}';
            exit;
        } else {
            $page_data['data'] = $out;
            echo json_encode($page_data);
            exit;
        }
    }
    public function getHarga()
    {
        $id_req = $this->input->post('id_req');
        $db = $this->M_Logistik_farmasi->getTotal($id_req);
        if (count($db) > 0) {
            $db = $db[0];
            $db->status_dt = 'found';
        } else {
            $db = null;
            $db['status_dt'] = 'not found';
        }
        echo json_encode($db);
        exit;
    }
    //END
    public function Laporan_Cetak_so()
    {
        $this->load->view('assets/_header');
        $page_data['page_content'] = 'page_content/Cetak_so';
        $this->load->view('Main', $page_data);
        $this->load->view('assets/_footer');
    }

    public function Tampil_cetak_so()
    {
        $page_data = $this->M_Logistik_farmasi->selectCetakSo();

        $out = null;
        for ($i = 0; $i < count($page_data); $i++) {
           
            $no = $i + 1;
            $nama = $page_data[$i]->nama;
            $tipe = $page_data[$i]->tipe;
            $stok = $page_data[$i]->stok;
            $produsen = $page_data[$i]->produsen;
            
            $out[$i] = array($no, $nama, $tipe, $stok,'', $produsen);
        }

        if ($out == null) {
            echo '{"data":""}';
            exit;
        } else {
            $page_data['data'] = $out;
            echo json_encode($page_data);
            exit;
        }
    }
}