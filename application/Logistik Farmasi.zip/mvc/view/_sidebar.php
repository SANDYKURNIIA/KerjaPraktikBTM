<?php

$data = $this->session->userdata('data_auth');
$datatipe = $data->tipe;

?>

<!-- Left Sidebar Menu -->

<div class="fixed-sidebar-left">

	<ul class="nav navbar-nav side-nav nicescroll-bar">

		<?php if ($datatipe == 'rekam medis') { ?>

			<li>
				<a href="<?= base_url('Pencarian_pasien') ?>"><i class="icon-magnifier mr-10"></i>PENCARIAN PASIEN</a>
			</li>
			<li>
				<a href="<?= base_url('Pelayanan_masuk') ?>"><i class="icon-docs mr-10"></i>PELAYANAN MASUK</a>
			</li>

			<li>
				<a style="cursor:pointer;" data-toggle="collapse" data-target="#dashboard_dr"><i class="icon-people mr-10"></i>PASIEN <span class="pull-right"><span class="label label-success mr-10">2</span><i class="fa fa-fw fa-angle-down"></i></span></a>
				<ul id="dashboard_dr" class="collapse collapse-level-1">
					<li>
						<a href="<?= base_url('Pasien/Pasien_rajal') ?>">RAWAT JALAN / IGD</a>
					</li>
					<li>
						<a href="<?= base_url('Pasien/Pasien_ranap') ?>">RAWAT INAP</a>
					</li>
					<li>
						<a href="<?= base_url('Pasien/Pasien_apm') ?>">ANJUNGAN PENDAFTARAN MANDIRI(APM)</a>
					</li>
				</ul>
			</li>
			<li>
				<a data-toggle="collapse" style="cursor:pointer;" data-target="#ui_dr"><i class="icon-user-following mr-10"></i>PASIEN ONLINE<span class="pull-right"><span class="label label-success mr-10">3</span><i class="fa fa-fw fa-angle-down"></i></span></a>
				<ul id="ui_dr" class="collapse collapse-level-1">
					<li>
						<a href="<?= base_url('Pasien_online/Pendaftaran_akun'); ?>">PENDAFTARAN AKUN</a>
					</li>
					<li>
						<a href="<?= base_url('Pasien_online/Konfirmasi_kehadiran'); ?>">KONFIRMASI KEHADIRAN</a>
					</li>
					<li>
						<a href="<?= base_url('Pasien_online/Poli_online'); ?>">POLI ONLINE</a>
					</li>

				</ul>
			</li>

			<li>
				<a href="<?= base_url('Assembling'); ?>"><i class="icon-docs mr-10"></i>ASSEMBLING</a>
			</li>

			<li>
				<a style="cursor:pointer;" data-toggle="collapse" data-target="#erm_dr"><i class="ti-support mr-10"></i>ERM<span class="pull-right"><span class="label label-success mr-10">2</span><i class="fa fa-fw fa-angle-down"></i></span></a>
				<ul id="erm_dr" class="collapse collapse-level-1">
					<li>
						<a href="<?= base_url('Erm') ?> ">PRINT OUT</a>
					</li>

					<li>
						<a href="<?= base_url('Erm/form') ?> ">FORM</a>
					</li>


				</ul>
			</li>


			<li>
				<a style="cursor:pointer;" data-toggle="collapse" data-target="#chart_dr"><i class="icon-graph mr-10"></i>LAPORAN<span class="pull-right"><span class="label label-success mr-10">3</span><i class="fa fa-fw fa-angle-down"></i></span></a>
				<ul id="chart_dr" class="collapse collapse-level-1">
					<li>
						<a href="<?= base_url('Laporan') ?>">LAPORAN PELAYANAN RAJAL</a>
					</li>
					<li>
						<a href="<?= base_url('Laporan/kunjungan'); ?>">LAPORAN KUNJUNGAN</a>
					</li>
					<li>
						<a href="<?= base_url('Laporan/pt'); ?>">LAPORAN PENYAKIT TERTINGGI</a>
					</li>

				</ul>
			</li>

			<li>
				<a href="widgets.html"><i class="icon-drawar mr-10"></i>PERMINTAAN LOGISTIK UMUM</a>
			</li>

			<li>
				<a href="<?= base_url('Antrian_poli') ?>"><i class="icon-hourglass mr-10"></i>ANTRIAN POLI</a>
			</li>

		<?php } elseif ($datatipe == 'igd') { ?>
			<!-- IGD -->
			<li>
				<a href="<?= base_url('IGD') ?>"><i class="icon-hourglass mr-10"></i>PASIEN IGD</a>
			</li>

			<li>
				<a href="<?= base_url('IGD') ?>"><i class="icon-hourglass mr-10"></i>LOGISTIK UMUM</a>
			</li>

		<?php } elseif ($datatipe == 'poliinternis') { ?>
			<!--  -->

			<!-- POLI INTERNIS -->
			<li>
				<a href="<?= base_url('Poli_internis') ?>"><i class="icon-hourglass mr-10"></i>PASIEN POLI INTERNIS</a>
			</li>

			<li>
				<a data-toggle="collapse" data-target="#dashboard_dr"><i class="icon-drawar mr-10"></i>ANTRIAN PASIEN <span class="pull-right"><span class="label label-success mr-10"></span><i class="fa fa-fw fa-angle-down"></i></span></a>
				<ul id="dashboard_dr" class="collapse collapse-level-1">
					<li>
						<a href="<?= base_url('Poli_internis/antrian_poli'); ?>"><i class="icon-drawar mr-10 "></i>ANTRIAN</a>
					</li>
				</ul>
			</li>

			<!--  -->

		<?php } elseif ($datatipe == 'poliobgyne') { ?>

			<!-- POLI OBGYNE -->
			<li>
				<a href="<?= base_url('Poli_obgyne') ?>"><i class="icon-hourglass mr-10"></i>PASIEN POLI OBGYNE</a>
			</li>

			<li>
				<a data-toggle="collapse" data-target="#dashboard_dr"><i class="icon-drawar mr-10"></i>ANTRIAN PASIEN <span class="pull-right"><span class="label label-success mr-10"></span><i class="fa fa-fw fa-angle-down"></i></span></a>
				<ul id="dashboard_dr" class="collapse collapse-level-1">
					<li>
						<a href="<?= base_url('Poli_obgyne/antrian_poli'); ?>"><i class="icon-drawar mr-10 "></i>ANTRIAN</a>
					</li>
				</ul>
			</li>

			<!--  -->

		<?php } elseif ($datatipe == 'politht') { ?>

			<!-- POLI THT -->
			<li>
				<a href="<?= base_url('Poli_tht') ?>"><i class="icon-hourglass mr-10"></i>PASIEN POLI THT</a>
			</li>

			<li>
				<a data-toggle="collapse" data-target="#dashboard_dr"><i class="icon-drawar mr-10"></i>ANTRIAN PASIEN <span class="pull-right"><span class="label label-success mr-10"></span><i class="fa fa-fw fa-angle-down"></i></span></a>
				<ul id="dashboard_dr" class="collapse collapse-level-1">
					<li>
						<a href="<?= base_url('Poli_tht/antrian_poli'); ?>"><i class="icon-drawar mr-10 "></i>ANTRIAN</a>
					</li>
				</ul>
			</li>

		<?php } elseif ($datatipe === 'polimata') { ?>
			<!--  -->

			<!-- POLI MATA -->
			<li>
				<a href="<?= base_url('Poli_mata') ?>"><i class="icon-hourglass mr-10"></i>PASIEN POLI MATA</a>
			</li>

			<li>
				<a data-toggle="collapse" data-target="#dashboard_dr"><i class="icon-drawar mr-10"></i>ANTRIAN PASIEN <span class="pull-right"><span class="label label-success mr-10"></span><i class="fa fa-fw fa-angle-down"></i></span></a>
				<ul id="dashboard_dr" class="collapse collapse-level-1">
					<li>
						<a href="Antrian_Poli_tht"><i class="icon-drawar mr-10 "></i>ANTRIAN</a>
					</li>
				</ul>
			</li>
			<!--  -->


		<?php } elseif ($datatipe == 'polikulit') { ?>

			<!-- POLI KULIT -->
			<li>
				<a href="<?= base_url('Poli_kulit') ?>"><i class="icon-hourglass mr-10"></i>PASIEN POLI KULIT</a>
			</li>

			<li>
				<a data-toggle="collapse" data-target="#dashboard_dr"><i class="icon-drawar mr-10"></i>ANTRIAN PASIEN <span class="pull-right"><span class="label label-success mr-10"></span><i class="fa fa-fw fa-angle-down"></i></span></a>
				<ul id="dashboard_dr" class="collapse collapse-level-1">
					<li>
						<a href="Antrian_Poli_tht"><i class="icon-drawar mr-10 "></i>ANTRIAN</a>
					</li>
				</ul>
			</li>

			<!--  -->
		<?php } elseif ($datatipe == 'poliumum') { ?>

			<!-- POLI UMUM -->
			<li>
				<a href="<?= base_url('Poli_umum') ?>"><i class="icon-hourglass mr-10"></i>PASIEN POLI UMUM</a>
			</li>

			<li>
				<a data-toggle="collapse" data-target="#dashboard_dr"><i class="icon-drawar mr-10"></i>ANTRIAN PASIEN <span class="pull-right"><span class="label label-success mr-10"></span><i class="fa fa-fw fa-angle-down"></i></span></a>
				<ul id="dashboard_dr" class="collapse collapse-level-1">
					<li>
						<a href="Antrian_Poli_tht"><i class="icon-drawar mr-10 "></i>ANTRIAN</a>
					</li>
				</ul>
			</li>

			<!--  -->


		<?php } elseif ($datatipe == 'polianak') { ?>

			<!-- POLI ANAK -->
			<li>
				<a href="<?= base_url('Poli_anak') ?>"><i class="icon-hourglass mr-10"></i>PASIEN POLI ANAK</a>
			</li>

			<li>
				<a data-toggle="collapse" data-target="#dashboard_dr"><i class="icon-drawar mr-10"></i>ANTRIAN PASIEN <span class="pull-right"><span class="label label-success mr-10"></span><i class="fa fa-fw fa-angle-down"></i></span></a>
				<ul id="dashboard_dr" class="collapse collapse-level-1">
					<li>
						<a href="Antrian_Poli_tht"><i class="icon-drawar mr-10 "></i>ANTRIAN</a>
					</li>
				</ul>
			</li>

			<!--  -->

		<?php } elseif ($datatipe == 'poligigi') { ?>

			<!-- POLI GIGI-->
			<li>
				<a href="<?= base_url('Poli_gigi') ?>"><i class="icon-hourglass mr-10"></i>PASIEN POLI GIGI</a>
			</li>

			<li>
				<a data-toggle="collapse" data-target="#dashboard_dr"><i class="icon-drawar mr-10"></i>ANTRIAN PASIEN <span class="pull-right"><span class="label label-success mr-10"></span><i class="fa fa-fw fa-angle-down"></i></span></a>
				<ul id="dashboard_dr" class="collapse collapse-level-1">
					<li>
						<a href="<?= base_url('Poli_gigi/antrian_poli') ?>"><i class="icon-drawar mr-10 "></i>ANTRIAN</a>
					</li>
				</ul>
			</li>

			<!--  -->

		<?php } elseif ($datatipe == 'polijantung') { ?>

			<!-- POLI JANTUNG-->
			<li>
				<a href="<?= base_url('Poli_jantung') ?>"><i class="icon-hourglass mr-10"></i>PASIEN POLI JANTUNG</a>
			</li>

			<li>
				<a data-toggle="collapse" data-target="#dashboard_dr"><i class="icon-drawar mr-10"></i>ANTRIAN PASIEN <span class="pull-right"><span class="label label-success mr-10"></span><i class="fa fa-fw fa-angle-down"></i></span></a>
				<ul id="dashboard_dr" class="collapse collapse-level-1">
					<li>
						<a href="<?= base_url('Poli_jantung/antrian_poli') ?>"><i class="icon-drawar mr-10 "></i>ANTRIAN</a>
					</li>
				</ul>
			</li>

			<!--  -->

		<?php } elseif ($datatipe == 'polibedah') { ?>

			<!-- POLI BEDAH-->
			<li>
				<a href="<?= base_url('Poli_bedah') ?>"><i class="icon-hourglass mr-10"></i>PASIEN POLI BEDAH</a>
			</li>

			<li>
				<a data-toggle="collapse" data-target="#dashboard_dr"><i class="icon-drawar mr-10"></i>ANTRIAN PASIEN <span class="pull-right"><span class="label label-success mr-10"></span><i class="fa fa-fw fa-angle-down"></i></span></a>
				<ul id="dashboard_dr" class="collapse collapse-level-1">
					<li>
						<a href="<?= base_url('Poli_bedah/antrian_poli') ?>"><i class="icon-drawar mr-10 "></i>ANTRIAN</a>
					</li>
				</ul>
			</li>

			<!--  -->



		<?php } elseif ($datatipe == 'polifisio') { ?>

			<!-- POLI FISIO -->
			<li>
				<a href="<?= base_url('Poli_fisio') ?>"><i class="icon-hourglass mr-10"></i>PASIEN POLI FISIO</a>
			</li>

			<li>
				<a data-toggle="collapse" data-target="#dashboard_dr"><i class="icon-drawar mr-10"></i>ANTRIAN PASIEN <span class="pull-right"><span class="label label-success mr-10"></span><i class="fa fa-fw fa-angle-down"></i></span></a>
				<ul id="dashboard_dr" class="collapse collapse-level-1">
					<li>
						<a href="<?= base_url('Poli_fisio/antrian_poli') ?>"><i class="icon-drawar mr-10 "></i>ANTRIAN</a>
					</li>
				</ul>
			</li>

			<!--  -->

		<?php } elseif ($datatipe == 'radiologi') { ?>

			<!-- RADIOLOGI-->
			<li>
				<a data-toggle="collapse" style="cursor:pointer;" data-target="#ui_rad"><i class="icon-user-following mr-10"></i>PASIEN<span class="pull-right"><span class="label label-success mr-10">2</span><i class="fa fa-fw fa-angle-down"></i></span></a>
				<ul id="ui_rad" class="collapse collapse-level-1">
					<li>
						<a href="<?= base_url('Radiologi/rajal') ?>"><i class="icon-user-follow mr-10 "></i>RAWAT
							JALAN/UGD</a>
					</li>
					<li>
						<a href="<?= base_url('Radiologi/ranap') ?>"><i class="icon-user-follow mr-10 "></i>RAWAT INAP</a>
					</li>
				</ul>
			</li>

			<li>
				<a data-toggle="collapse" style="cursor:pointer;" data-target="#ui_rad-riw"><i class="icon-equalizer mr-10"></i>RIWAYAT<span class="pull-right"><span class="label label-success mr-10">1</span><i class="fa fa-fw fa-angle-down"></i></span></a>
				<ul id="ui_rad-riw" class="collapse collapse-level-1">
					<li>
						<a href=""><i class="icon-calculator mr-10 "></i>JUMLAH STOK OBAT &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;& BMHP</a>
					</li>
				</ul>
			</li>

			<li>
				<a data-toggle="collapse" style="cursor:pointer;" data-target="#ui_admin"><i class="icon-grid mr-10"></i>ADMIN<span class="pull-right"><span class="label label-success mr-10">5</span><i class="fa fa-fw fa-angle-down"></i></span></a>
				<ul id="ui_admin" class="collapse collapse-level-1">
					<li>
						<a href="Antrian_Poli_fisio"><i class="icon-drawar mr-10 "></i>RIWAYAT PASIEN</a>
					</li>
					<li>
						<a href=""><i class="icon-social-dropbox mr-10 "></i>PERMINTAAN &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;LOGISTIK UMUM</a>
					</li>
					<li>
						<a href="<?= base_url('Permintaan_obat') ?>"><i class="icon-social-dropbox mr-10 "></i>PERMINTAAN OBAT &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;& BMHP</a>
					</li>
					<li>
						<a href=""><i class="icon-chart mr-10 "></i>LAPORAN &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;RADIOLOGI</a>
					</li>
					<li>
						<a href=""><i class="icon-chart mr-10 "></i>LAPORAN &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;RADIOLOGI &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;TINDAKAN</a>
					</li>
				</ul>
			</li>

			<!--  -->

		<?php } elseif ($datatipe == 'ok') { ?>
			<!-- OK -->
			<li>
				<a href="<?= base_url('OK_pasien') ?>"><i class="icon-drawar mr-10 "></i>PASIEN </a>
			</li>

			<li>
				<a href=""><i class="icon-drawar mr-10 "></i>RIWAYAT PASIEN </a>
			</li>
			<li>
				<a href="<?= base_url('Permintaan_obat') ?>"><i class="icon-drawar mr-10 "></i>PERMINTAAN OBAT </a>
			</li>
			<li>
				<a href=""><i class="icon-drawar mr-10 "></i>STOCK OBAT </a>
			</li>
			<li>
				<a href=""><i class="icon-drawar mr-10 "></i>CETAK SO OK</a>
			</li>

			<!--  -->

		<?php } elseif ($datatipe == 'labor') { ?>

			<!-- LABOR -->
			<li>
				<a data-toggle="collapse" style="cursor:pointer;" data-target="#ui_rad"><i class="icon-user-following mr-10"></i>PASIEN<span class="pull-right"><span class="label label-success mr-10">2</span><i class="fa fa-fw fa-angle-down"></i></span></a>
				<ul id="ui_rad" class="collapse collapse-level-1">
					<li>
						<a href="<?= base_url('Labor/rajal') ?>"><i class="icon-user-follow mr-10 "></i>RAWAT
							JALAN/UGD</a>
					</li>
					<li>
						<a href="<?= base_url('Labor/ranap') ?>"><i class="icon-user-follow mr-10 "></i>RAWAT INAP</a>
					</li>
				</ul>
			</li>

			<li>
				<a href=""><i class="icon-calculator mr-10 "></i>PERMINTAAN STOK &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;OBAT & BMHP</a>
			</li>

			<li>
				<a data-toggle="collapse" style="cursor:pointer;" data-target="#ui_admin"><i class="icon-grid mr-10"></i>ADMIN<span class="pull-right"><span class="label label-success mr-10">3</span><i class="fa fa-fw fa-angle-down"></i></span></a>
				<ul id="ui_admin" class="collapse collapse-level-1">
					<li>
						<a href=""><i class="icon-drawar mr-10 "></i>RIWAYAT PASIEN</a>
					</li>
					<li>
						<a href=""><i class="icon-doc mr-10 "></i>LAPORAN LABOR</a>
					</li>
					<li>
						<a href=""><i class="icon-doc mr-10 "></i>LAPORAN LABOR &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;TINDAKAN</a>
					</li>
				</ul>
			</li>

			<li>
				<a href=""><i class="icon-social-dropbox mr-10 "></i>PERMINTAAN LOGISTIK &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;UMUM</a>
			</li>

			<!--  -->
		<?php } elseif ($datatipe == 'logistik farmasi') { ?>
			<li>
				<a href="<?= base_url('Pembelian_obat') ?>"><i class="icon-magnifier mr-10"></i>PEMBELIAN OBAT</a>
			</li>

			<li>
				<a style="cursor:pointer;" data-toggle="collapse" data-target="#dashboard_dr"><i class="icon-people mr-10"></i>OBAT TERSEDIA <span class="pull-right"><span class="label label-success mr-10">3</span><i class="fa fa-fw fa-angle-down"></i></span></a>
				<ul id="dashboard_dr" class="collapse collapse-level-1">
					<li>
						<a href="<?= base_url('Pendaftaran_akun') ?>">STOK OBAT</a>
					</li>
					<li>
						<a href="<?= base_url('Assembling') ?>">STOK PER ED</a>
					</li>
					<li>
						<a href="<?= base_url('Pasien/Pasien_ranap') ?>">RIWAYAT PEMBELIAN</a>
					</li>
				</ul>
			</li>

			<li>
				<a href="<?= base_url('Logistik_farmasi/Riwayat_permintaan') ?>"><i class="icon-magnifier mr-10"></i>RIWAYAT PERMINTAAN OBAT</a>
			</li>

			<li>
				<a href="<?= base_url('Poli_anak') ?>"><i class="icon-magnifier mr-10"></i>RIWAYAT PENARIKAN OBAT</a>
			</li>


			<li>
				<a data-toggle="collapse" style="cursor:pointer;" data-target="#ui_dr"><i class="icon-drawar mr-10"></i>LAPORAN<span class="pull-right"><span class="label label-success mr-10">7</span><i class="fa fa-fw fa-angle-down"></i></span></a>
				<ul id="ui_dr" class="collapse collapse-level-1">
					<li>
						<a href="<?= base_url('Logistik_farmasi/Laporan_mutasi'); ?>">LAPORAN MUTASI</a>
					</li>
					<li>
						<a href="<?= base_url('Logistik_farmasi/Pengeluaran_Obat'); ?>">PENGELUARAN OBAT</a>
					</li>
					<li>
						<a href="<?= base_url('Logistik_farmasi/Laporan_pembelian'); ?>">LAPORAN PEMBELIAN</a>
					</li>
					<li>
						<a href="<?= base_url('Logistik_farmasi/Laporan_Cetak_so'); ?>">CETAK SO</a>
					</li>
					<li>
						<a href="<?= base_url('Pasien_online/Poli_online'); ?>">CETAK SO APOTIK</a>
					</li>

					<li>
						<a href="<?= base_url('Pasien_online/Poli_online'); ?>">CETAK SO APOTIK</a>
					</li>

					<li>
						<a href="<?= base_url('Pasien_online/Poli_online'); ?>">CETAK SO IGD</a>
					</li>

					<li>
						<a href="<?= base_url('Logistik_farmasi/Laporan_po_kundur'); ?>">CETAK PEMBELIAN OBAT KUNDUR</a>
					</li>

				</ul>
			</li>


			<li>
				<a style="cursor:pointer;" data-toggle="collapse" data-target="#erm_dr"><i class="icon-drawar mr-10"></i>ADMIN<span class="pull-right"><span class="label label-success mr-10">4</span><i class="fa fa-fw fa-angle-down"></i></span></a>
				<ul id="erm_dr" class="collapse collapse-level-1">
					<li>
						<a href="<?= base_url('Erm') ?> ">DISTRIBUTOR OBAT</a>
					</li>

					<li>
						<a href="<?= base_url('Erm/form') ?> ">OBAT</a>
					</li>

					<li>
						<a href="<?= base_url('Erm/form') ?> ">PRODUSEN OBAT</a>
					</li>

					<li>
						<a href="<?= base_url('Po_obat') ?> ">PO OBAT</a>
					</li>

				</ul>
			</li>


			<li>
				<a href="widgets.html"><i class="icon-drawar mr-10"></i>PERMINTAAN LOGISTIK UMUM</a>
			</li>
		<?php } elseif ($datatipe == 'logistikumum') { ?>
			<li>
			<li>
				<a class="klik_menu" id="inputfaktur" href="javascript:void(0);"><i class="icon-layers mr-10 "></i>INPUT FAKTUR</a>
			</li>

			<li>
				<a class="klik_menu" id="obattersedia" href="javascript:void(0);"><i class="icon-notebook mr-10 "></i> STOK BARANG</a>
			</li>
			<li>
				<a class="klik_menu" id="listmutasi" href="javascript:void(0);"><i class="icon-notebook mr-10 "></i>RIWAYAT PERMINTAAN BARANG</a>
			</li>
			<li>
				<a data-toggle="collapse" data-target="#dashboard_drr" href="javascript:void(0);"><i class="icon-note mr-10"></i>LAPORAN <span class="pull-right"><span class="label label-success mr-10">4</span><i class="fa fa-fw fa-angle-down"></i></span></a>
				<ul id="dashboard_drr" class="collapse collapse-level-1">
					<li>
						<a class="klik_menu" href="<?= base_url('Logistik_umum/Laporan_mutasi') ?> ">LAPORAN MUTASI</a>
					</li>
					<li>
						<a class="klik_menu" id="laporanpembelian" href="javascript:void(0);">LAPORAN PEMBELIAN</a>
					</li>
					<li>
						<a class="klik_menu" id="daftarpermintaan" href="javascript:void(0);">DAFTAR PERMINTAAN</a>
					</li>
					<li>
						<a class="klik_menu" id="bebanpermintaan" href="javascript:void(0);">BEBAN PERMINTAAN</a>
					</li>
					<li>
						<a class="klik_menu" id="rekappembelian" href="javascript:void(0);">REKAP PEMBELIAN</a>
					</li>
					<li>
						<a class="klik_menu" id="laporanSo" href="javascript:void(0);">CETAK SO</a>
					</li>

				</ul>
			</li>
			<li>
				<a data-toggle="collapse" data-target="#dashboard_dr" href="javascript:void(0);"><i class="icon-drawar mr-10"></i>ADMIN <span class="pull-right"><span class="label label-success mr-10">3</span><i class="fa fa-fw fa-angle-down"></i></span></a>
				<ul id="dashboard_dr" class="collapse collapse-level-1">
					<li>
						<a class="klik_menu" id="adminprodusen" href="<?= base_url('Daftar_vendor') ?>">DAFTAR VENDOR</a>
					</li>
					<li>
						<a class="klik_menu" id="adminobatlogistik" href="<?= base_url('Daftar_barang') ?>">DAFTAR BARANG</a>
					</li>
					
					<li>
						<a class="klik_menu" id="permintaanobatab" href="<?= base_url('Konfirmasi_permintaan ') ?>">KONFIRMASI PERMINTAAN LOGISTIK UMUM EXTERNAL</a>
					</li>
					<li>
						<a class="klik_menu" id="adminbuka" href="<?= base_url('Admin_buka_permintaan') ?>">ADMIN BUKA PERMINTAAN</a>
					</li>
				</ul>
			</li>
			</li>
		<?php } elseif ($datatipe == 'apotik') { ?>
			<li>
			<li>
				<a data-toggle="collapse" data-target="#dashboard_drr" href="javascript:void(0);"><i class="icon-note mr-10"></i>PASIEN <span class="pull-right"><span class="label label-success mr-10">4</span><i class="fa fa-fw fa-angle-down"></i></span></a>
				<ul id="dashboard_drr" class="collapse collapse-level-1">
					<li>
						<a class="klik_menu" href="<?= base_url('Logistik_umum/Laporan_mutasi') ?> ">LAPORAN MUTASI</a>
					</li>
					<li>
						<a class="klik_menu" id="laporanpembelian" href="javascript:void(0);">LAPORAN PEMBELIAN</a>
					</li>
					<li>
						<a class="klik_menu" id="daftarpermintaan" href="javascript:void(0);">DAFTAR PERMINTAAN</a>
					</li>
					<li>
						<a class="klik_menu" id="bebanpermintaan" href="javascript:void(0);">BEBAN PERMINTAAN</a>
					</li>
					<li>
						<a class="klik_menu" id="rekappembelian" href="javascript:void(0);">REKAP PEMBELIAN</a>
					</li>
					<li>
						<a class="klik_menu" id="laporanSo" href="javascript:void(0);">CETAK SO</a>
					</li>

				</ul>
			</li>

			<li>
				<a data-toggle="collapse" data-target="#dashboard_obat" href="javascript:void(0);"><i class="icon-note mr-10"></i>OBAT <span class="pull-right"><span class="label label-success mr-10">4</span><i class="fa fa-fw fa-angle-down"></i></span></a>
				<ul id="dashboard_obat" class="collapse collapse-level-1">
					<li>
						<a class="klik_menu" href="<?= base_url('Permintaan_obat') ?> ">PERMINTAAN OBAT</a>
					</li>
					<li>
						<a class="klik_menu" id="laporanpembelian" href="javascript:void(0);">STOK OBAT APOTIK</a>
					</li>
					<li>
						<a class="klik_menu" id="daftarpermintaan" href="javascript:void(0);">STOK OBAT IGD</a>
					</li>
				</ul>
			</li>
			<li>
				<a class="klik_menu" id="listmutasi" href="javascript:void(0);"><i class="icon-notebook mr-10 "></i>RIWAYAT PERMINTAAN BARANG</a>
			</li>
			<li>
				<a data-toggle="collapse" data-target="#dashboard_drr" href="javascript:void(0);"><i class="icon-note mr-10"></i>LAPORAN <span class="pull-right"><span class="label label-success mr-10">4</span><i class="fa fa-fw fa-angle-down"></i></span></a>
				<ul id="dashboard_drr" class="collapse collapse-level-1">
					<li>
						<a class="klik_menu" href="<?= base_url('Logistik_umum/Laporan_mutasi') ?> ">LAPORAN MUTASI</a>
					</li>
					<li>
						<a class="klik_menu" id="laporanpembelian" href="javascript:void(0);">LAPORAN PEMBELIAN</a>
					</li>
					<li>
						<a class="klik_menu" id="daftarpermintaan" href="javascript:void(0);">DAFTAR PERMINTAAN</a>
					</li>
					<li>
						<a class="klik_menu" id="bebanpermintaan" href="javascript:void(0);">BEBAN PERMINTAAN</a>
					</li>
					<li>
						<a class="klik_menu" id="rekappembelian" href="javascript:void(0);">REKAP PEMBELIAN</a>
					</li>
					<li>
						<a class="klik_menu" id="laporanSo" href="javascript:void(0);">CETAK SO</a>
					</li>

				</ul>
			</li>
			<li>
				<a data-toggle="collapse" data-target="#dashboard_dr" href="javascript:void(0);"><i class="icon-drawar mr-10"></i>ADMIN <span class="pull-right"><span class="label label-success mr-10">3</span><i class="fa fa-fw fa-angle-down"></i></span></a>
				<ul id="dashboard_dr" class="collapse collapse-level-1">
					<li>
						<a class="klik_menu" id="adminprodusen" href="<?= base_url('Daftar_vendor') ?>">DAFTAR VENDOR</a>
					</li>
					<li>
						<a class="klik_menu" id="adminobatlogistik" href="<?= base_url('Daftar_barang') ?>">DAFTAR BARANG</a>
					</li>
					
					<li>
						<a class="klik_menu" id="permintaanobatab" href="<?= base_url('Konfirmasi_permintaan ') ?>">KONFIRMASI PERMINTAAN LOGISTIK UMUM EXTERNAL</a>
					</li>
					<li>
						<a class="klik_menu" id="adminbuka" href="<?= base_url('Admin_buka_permintaan') ?>">ADMIN BUKA PERMINTAAN</a>
					</li>
				</ul>
			</li>
			</li>
			
		<?php } else { ?>

			<?php redirect('../accounts'); ?>

		<?php } ?>

	</ul>
</div>
<!-- /Left Sidebar Menu -->