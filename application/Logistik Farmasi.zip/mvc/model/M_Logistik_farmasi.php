<?php

class M_Logistik_farmasi extends CI_Model
{

    // Laporan Mutasi
    public function selectLaporanmutasiFarmasi()
    {
        date_default_timezone_set('Asia/Jakarta');
        $tgl = date("Y-m-d");
        $this->db->select('l.nama,s.asal_tujuan tipe,s.frek jml_terima, s.tgl tgl_res, s.keterangan ket');
        $this->db->from('stok_logistik s, list_logistik l');
        $this->db->where('s.id_logistik=l.id_logistik');
        $this->db->where("(s.keterangan= 'PENARIKAN' OR s.keterangan = 'MUTASI')");
        $this->db->like('s.tgl', $tgl);
        $this->db->order_by('tipe, nama');
        return $this->db->get()->result();
    }

    public function selectRangeLaporanmutasiFarmasi($mulai, $akhir)
    {
        $this->db->select('l1.nama,s1.asal_tujuan tipe,s1.frek jml_terima, s1.tgl tgl_res, s1.keterangan ket');
        $this->db->from('stok_logistik s1, list_logistik l1');
        $this->db->where('s1.id_logistik=l1.id_logistik');
        $this->db->where("(s1.keterangan= 'PENARIKAN' OR s1.keterangan = 'MUTASI')");
        $this->db->where('s1.tgl >=', $mulai);
        $this->db->where('s1.tgl <=', $akhir);
        $this->db->order_by('tipe, nama');
        return $this->db->get()->result();
    }
    // End

    //Pengeluaran obat
    public function selectPengeluaranObat()
    {
        date_default_timezone_set('Asia/Jakarta');
        $tgl = date("Y-m-d");
        $this->db->select('l.nama,sum(s.frek) stok');
        $this->db->from('stok_logistik s, list_logistik l');
        $this->db->where('s.id_logistik=l.id_logistik');
        $this->db->where('s.keterangan', 'MUTASI');
        $this->db->like('s.tgl', $tgl);
        $this->db->group_by('s.id_logistik');
        $this->db->order_by('nama');
        return $this->db->get()->result();
    }

    public function selectRangePengeluaranObat($mulai, $akhir)
    {
        $this->db->select('l.nama,sum(s.frek) stok');
        $this->db->from('stok_logistik s, list_logistik l');
        $this->db->where('s.id_logistik=l.id_logistik');
        $this->db->where('s.keterangan', 'MUTASI');
        $this->db->where('s.tgl >=', $mulai);
        $this->db->where('s.tgl <=', $akhir);
        $this->db->group_by('s.id_logistik');
        $this->db->order_by('nama');
        return $this->db->get()->result();
    }
    // End

    //Laporan Pembelian
    public function selectLaporanPembelian()
    {
        date_default_timezone_set('Asia/Jakarta');
        $tgl = date("Y-m-d");
        $this->db->select('s.no_faktur,d.id_prod_obat,l.nama,l.tipe,l.golongan_obat, p.nama_produsen, d.frek, d.harga,d.total,s.tgl_masuk, d.harga_beli, d.ppn, d.diskon_rs, d.diskon ');
        $this->db->from('struk_logistik s , detail_struk d , list_logistik l , produsen p');
        $this->db->where('s.id_struk=d.id_struk');
        $this->db->where('d.id_logistik=l.id_logistik');
        $this->db->where('s.id_produsen=p.id_produsen');
        $this->db->like('s.tgl_masuk', $tgl);
        $this->db->order_by('s.no_faktur');
        return $this->db->get()->result();
    }

    public function selectRangeLaporanPembelian($mulai, $akhir)
    {
        $this->db->select('s.no_faktur,d.id_prod_obat,l.nama,l.tipe,l.golongan_obat, p.nama_produsen, d.frek, d.harga,d.total,s.tgl_masuk, d.harga_beli, d.ppn, d.diskon_rs, d.diskon ');
        $this->db->from('struk_logistik s , detail_struk d , list_logistik l , produsen p');
        $this->db->where('s.id_struk=d.id_struk');
        $this->db->where('d.id_logistik=l.id_logistik');
        $this->db->where('s.id_produsen=p.id_produsen');
        $this->db->where('s.tgl_masuk >=', $mulai);
        $this->db->where('s.tgl_masuk <=', $akhir);
        $this->db->order_by('s.no_faktur');
        return $this->db->get()->result();
    }
    // End

    //Laporan Pembelian Obat Kundur
    public function selectLaporanPoKundur()
    {
        date_default_timezone_set('Asia/Jakarta');
        $tgl = date("Y-m-d");
        $this->db->select('*');
        $this->db->from('request_obat r, staff s');
        $this->db->where('s.id_staff=r.id_staff');
        $this->db->where('s.tipe', 'Klinik Pratama Kundur');
        $this->db->order_by('tanggal desc');
        return $this->db->get()->result();
    }

    public function selectTindakanById($id_req)
    {
        date_default_timezone_set('Asia/Jakarta');
        $tgl = date("Y-m-d");
        $this->db->select('l.nama,l.harga_cost,l.tipe, dr.*');
        $this->db->from('detail_request dr , request_obat r, list_logistik l');
        $this->db->where('dr.id_form=r.id_req');
        $this->db->where('dr.id_logistik=l.id_logistik');
        $this->db->where('dr.id_form', $id_req);
        $this->db->where('dr.status', 'DITERIMA');
        return $this->db->get()->result();
    }
    public function getTotal($id_req)
    {
        date_default_timezone_set('Asia/Jakarta');
        $tgl = date("Y-m-d");
        $this->db->select('l.harga_cost, dr.jml_terima');
        $this->db->from('detail_request dr , request_obat r, list_logistik l');
        $this->db->where('dr.id_form=r.id_req');
        $this->db->where('dr.id_logistik=l.id_logistik');
        $this->db->where('dr.id_form', $id_req);
        return $this->db->get()->result();
    }
    public function selectCetakSo()
    {
        date_default_timezone_set('Asia/Jakarta');
        $tgl = date("Y-m-d");
        $this->db->select('l.nama , sum(s.frek) stok, l.tipe, l.produsen');
        $this->db->from('list_logistik l');
        $this->db->join('stok_logistik s', 's.id_logistik=l.id_logistik', 'left');
        $this->db->where_not_in('l.id_logistik', 'setrip1');
        $this->db->group_by('l.id_logistik ');
        $this->db->order_by('l.nama asc');
        return $this->db->get()->result();
    }
    // Riwayat Permintaan Obat
    public function selectRiwayatPermintaanObat()
    {
        date_default_timezone_set('Asia/Jakarta');
        $tgl = date("Y-m-d");
        $this->db->select('r.*,s.tipe,s.nama ');
        $this->db->from('request_obat r, staff s');
        $this->db->where('s.id_staff=r.id_staff');
        $this->db->like('r.tanggal', $tgl);
        $this->db->order_by('r.tanggal desc');
        return $this->db->get()->result();
    }
    public function countRiwayatPermintaan($id)
    {
        $this->db->select('*');
        $this->db->from(' detail_request');
        $this->db->where('id_form', $id);
        $this->db->where('status', 'DIAJUKAN');
        return $this->db->get()->num_rows();
    }

    public function selectRangeRiwayatPermintaanObat($mulai, $akhir)
    {
        $this->db->select('r.*,s.tipe,s.nama ');
        $this->db->from('request_obat r, staff s');
        $this->db->where('s.id_staff=r.id_staff');
        $this->db->where('r.tanggal >=', $mulai);
        $this->db->where('r.tanggal <=', $akhir);
        $this->db->order_by('r.tanggal desc');
        return $this->db->get()->result();
    }
    public function getListRiwayatPermintaanObat($id)
    {
        date_default_timezone_set('Asia/Jakarta');
        $tgl = date("Y-m-d");
        $this->db->select('l.nama, dr.*, s1.tipe, s1.id_staff');
        $this->db->from('detail_request dr , request_obat r, list_logistik l, staff s, staff s1');
        $this->db->where('dr.id_form=r.id_req ');
        $this->db->where('dr.id_logistik=l.id_logistik ');
        $this->db->where('s.id_staff=dr.id_staff ');
        $this->db->where('s1.id_staff=r.id_staff ');
        $this->db->like('dr.id_form', $id);
        return $this->db->get()->result();
    }
    public function getStokByRiwayatPermintaan($tgl_exp, $id_log)
    {
        $this->db->select('SUM(s.frek) stok, l.nama  jumlah');
        $this->db->from('stok_logistik s, list_logistik l');
        $this->db->where('s.id_logistik=l.id_logistik');
        $this->db->where('s.kadaluarsa', $tgl_exp);
        $this->db->where('l.id_logistik', $id_log);
        return $this->db->get()->row();
    }
    // End
    public function insertStok($data, $table)
    {
        return $this->db->insert($table, $data);
    }
    public function update_detail_request($id, $data)
	{
		$this->db->where('id_req', $id);
		return $this->db->update('detail_request', $data);
	}

}
