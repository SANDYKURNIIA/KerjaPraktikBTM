<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Logistik_farmasi extends CI_Controller
{
    function __construct()
    {
        parent::__construct();
        date_default_timezone_set('Asia/Jakarta');
        $this->load->model('M_Logistik_farmasi');
    }

    // Laporan mutasi
    public function Laporan_mutasi()
    {
        $this->load->view('assets/_header');
        $page_data['page_content'] = 'page_content/Laporan_mutasi_farmasi';
        $this->load->view('Main', $page_data);
        $this->load->view('assets/_footer');
    }

    public function Tampil_laporan_mutasi()
    {
        $page_data = $this->M_Logistik_farmasi->selectLaporanmutasiFarmasi();

        $out = null;
        for ($i = 0; $i < count($page_data); $i++) {
            $no = $i + 1;
            $jenis = $page_data[$i]->ket;
            $nama = $page_data[$i]->nama;
            $tipe = $page_data[$i]->tipe;
            $jml_terima = $page_data[$i]->jml_terima;
            $time = strtotime($page_data[$i]->tgl_res);
            $tgl = strftime("%A, %d %B %Y", $time);
            $waktu = strftime("%H:%M WIB", $time);
            $out[$i] = array($no, $jenis, $nama, $tipe, $jml_terima, $tgl, $waktu);
        }

        if ($out == null) {
            echo '{"data":""}';
            exit;
        } else {
            $page_data['data'] = $out;
            echo json_encode($page_data);
            exit;
        }
    }

    public function Tampil_Rangelaporan_mutasi()
    {

        $mulai = $this->input->post('mulai');
        $akhir = $this->input->post('akhir');

        $page_data = $this->M_Logistik_farmasi->selectRangeLaporanmutasiFarmasi($mulai, $akhir);

        $out = null;
        for ($i = 0; $i < count($page_data); $i++) {
            $no = $i + 1;
            $jenis = $page_data[$i]->ket;
            $nama = $page_data[$i]->nama;
            $tipe = $page_data[$i]->tipe;
            $jml_terima = $page_data[$i]->jml_terima;
            $time = strtotime($page_data[$i]->tgl_res);
            $tgl = strftime("%A, %d %B %Y", $time);
            $waktu = strftime("%H:%M WIB", $time);
            $out[$i] = array($no, $jenis, $nama, $tipe, $jml_terima, $tgl, $waktu);
        }

        if ($out == null) {
            echo '{"data":""}';
            exit;
        } else {
            $page_data['data'] = $out;
            echo json_encode($page_data);
            exit;
        }
    }


    // End

    //Pengeluaran Obat
    public function Pengeluaran_obat()
    {
        $this->load->view('assets/_header');
        $page_data['page_content'] = 'page_content/Laporan_pengeluaran_obat';
        $this->load->view('Main', $page_data);
        $this->load->view('assets/_footer');
    }

    public function Tampil_pengeluaran_obat()
    {
        $page_data = $this->M_Logistik_farmasi->selectPengeluaranObat();

        $out = null;
        for ($i = 0; $i < count($page_data); $i++) {
            $no = $i + 1;
            $nama = $page_data[$i]->nama;
            $stok = $page_data[$i]->stok;
            $out[$i] = array($no, $nama, $stok);
        }

        if ($out == null) {
            echo '{"data":""}';
            exit;
        } else {
            $page_data['data'] = $out;
            echo json_encode($page_data);
            exit;
        }
    }

    public function Tampil_Range_Pengeluaran_obat()
    {

        $mulai = $this->input->post('mulai');
        $akhir = $this->input->post('akhir');

        $page_data = $this->M_Logistik_farmasi->selectRangePengeluaranObat($mulai, $akhir);

        $out = null;
        for ($i = 0; $i < count($page_data); $i++) {
            $no = $i + 1;
            $nama = $page_data[$i]->nama;
            $stok = $page_data[$i]->stok;
            $out[$i] = array($no, $nama, $stok);
        }

        if ($out == null) {
            echo '{"data":""}';
            exit;
        } else {
            $page_data['data'] = $out;
            echo json_encode($page_data);
            exit;
        }
    }

    //END

    
    //Laporan Pembelian
    public function Laporan_pembelian()
    {
        $this->load->view('assets/_header');
        $page_data['page_content'] = 'page_content/Laporan_pembelian_farmasi';
        $this->load->view('Main', $page_data);
        $this->load->view('assets/_footer');
    }

    public function Tampil_laporan_pembelian()
    {
        $page_data = $this->M_Logistik_farmasi->selectLaporanPembelian();

        $out = null;
        for ($i = 0; $i < count($page_data); $i++) {
            $no = " ". $page_data[$i]->no_faktur;
            $nama_produsen = $page_data[$i]->nama_produsen;
            $nama = $page_data[$i]->nama;
            $id_prod_obat = $page_data[$i]->id_prod_obat;
            $tipe = $page_data[$i]->tipe;
            $golongan_obat = $page_data[$i]->golongan_obat;
            $frek = $page_data[$i]->frek;
            $harga_beli = $page_data[$i]->harga_beli;
            $diskon = $page_data[$i]->diskon;
            $disc = $diskon/100 * $harga_beli*$frek;
            $ppn = $page_data[$i]->ppn;
            $total = $harga_beli*$frek;
            $time = strtotime($page_data[$i]->tgl_masuk);
            $tgl = strftime("%A, %d %B %Y", $time);
            $out[$i] = array($no, $nama_produsen, $nama, $id_prod_obat, $tipe, $golongan_obat, $frek, $harga_beli, $diskon, $disc, $ppn, $total, $tgl);
        }

        if ($out == null) {
            echo '{"data":""}';
            exit;
        } else {
            $page_data['data'] = $out;
            echo json_encode($page_data);
            exit;
        }
    }

    public function Tampil_Range_Pembelian()
    {

        $mulai = $this->input->post('mulai');
        $akhir = $this->input->post('akhir');

        $page_data = $this->M_Logistik_farmasi->selectRangeLaporanPembelian($mulai, $akhir);

        $out = null;
        for ($i = 0; $i < count($page_data); $i++) {
            $no = " ". $page_data[$i]->no_faktur;
            $nama_produsen = $page_data[$i]->nama_produsen;
            $nama = $page_data[$i]->nama;
            $id_prod_obat = $page_data[$i]->id_prod_obat;
            $tipe = $page_data[$i]->tipe;
            $golongan_obat = $page_data[$i]->golongan_obat;
            $frek = $page_data[$i]->frek;
            $harga_beli = $page_data[$i]->harga_beli;
            $diskon = $page_data[$i]->diskon;
            $disc = $diskon/100 * $harga_beli*$frek;
            $ppn = $page_data[$i]->ppn;
            $total = $harga_beli*$frek;
            $time = strtotime($page_data[$i]->tgl_masuk);
            $tgl = strftime("%A, %d %B %Y", $time);
            $out[$i] = array($no, $nama_produsen, $nama, $id_prod_obat, $tipe, $golongan_obat, $frek,  $frek,'', $harga_beli, $diskon, $disc, $ppn, $total, $tgl);
        }

        if ($out == null) {
            echo '{"data":""}';
            exit;
        } else {
            $page_data['data'] = $out;
            echo json_encode($page_data);
            exit;
        }
    }

    //END

    //Laporan Pembelian Obat Kundur
    public function Laporan_po_kundur()
    {
        $this->load->view('assets/_header');
        $page_data['page_content'] = 'page_content/Laporan_po_kundur';
        $this->load->view('Main', $page_data);
        $this->load->view('assets/_footer');
    }

    public function Tampil_laporan_po_kundur()
    {
        $page_data = $this->M_Logistik_farmasi->selectLaporanPoKundur();

        $out = null;
        for ($i = 0; $i < count($page_data); $i++) {
            $button = "<div class='btn btn-success btn-icon-anim btn-square' onclick='tampilPermintaanObat(\"" . $page_data[$i]->id_req ."\")'><i class='icon-pencil'></i></div>";
            
            $time = strtotime($page_data[$i]->tanggal);
            $tgl = strftime("%A, %d %B %Y", $time);
            $waktu = strftime("%H:%M WIB", $time);

            $no = $i + 1;
            $status = $page_data[$i]->status;
            
            $out[$i] = array($no, $button, $tgl, $waktu, $status);
        }

        if ($out == null) {
            echo '{"data":""}';
            exit;
        } else {
            $page_data['data'] = $out;
            echo json_encode($page_data);
            exit;
        }
    }
    
    public function tampil_list_tindakan(){
        $id_req = $this->input->post('id_req');
        $page_data = $this->M_Logistik_farmasi->selectTindakanById($id_req);

        $out = null;
        for ($i = 0; $i < count($page_data); $i++) {
            $no = $i + 1;
            $nama = $page_data[$i]->nama;
            $tipe = $page_data[$i]->tipe;
            $jml_terima = $page_data[$i]->jml_terima;
            $harga_cost = $page_data[$i]->harga_cost;
            $total = $harga_cost*$jml_terima;
            $out[$i] = array($no, $nama, $tipe, $jml_terima, $harga_cost, $total);
        }

        if ($out == null) {
            echo '{"data":""}';
            exit;
        } else {
            $page_data['data'] = $out;
            echo json_encode($page_data);
            exit;
        }
    }
    public function getHarga()
    {
        $id_req = $this->input->post('id_req');
        $db = $this->M_Logistik_farmasi->getTotal($id_req);
        if (count($db) > 0) {
            $db = $db[0];
            $db->status_dt = 'found';
        } else {
            $db = null;
            $db['status_dt'] = 'not found';
        }
        echo json_encode($db);
        exit;
    }
    //END
    public function Laporan_Cetak_so()
    {
        $this->load->view('assets/_header');
        $page_data['page_content'] = 'page_content/Cetak_so';
        $this->load->view('Main', $page_data);
        $this->load->view('assets/_footer');
    }

    public function Tampil_cetak_so()
    {
        $page_data = $this->M_Logistik_farmasi->selectCetakSo();

        $out = null;
        for ($i = 0; $i < count($page_data); $i++) {
           
            $no = $i + 1;
            $nama = $page_data[$i]->nama;
            $tipe = $page_data[$i]->tipe;
            $stok = $page_data[$i]->stok;
            $produsen = $page_data[$i]->produsen;
            
            $out[$i] = array($no, $nama, $tipe, $stok,'', $produsen);
        }

        if ($out == null) {
            echo '{"data":""}';
            exit;
        } else {
            $page_data['data'] = $out;
            echo json_encode($page_data);
            exit;
        }
    }
    //Riwayat Permintaan Obat
    public function Riwayat_permintaan()
    {
        $this->load->view('assets/_header');
        $page_data['page_content'] = 'page_content/Riwayat_permintaan_obat_farmasi';
        $this->load->view('Main', $page_data);
        $this->load->view('assets/_footer');
    }

    public function Tampil_riwayat_permintaan()
    {
        $page_data = $this->M_Logistik_farmasi->selectRiwayatPermintaanObat();
        
        $out = null;
        for ($i = 0; $i < count($page_data); $i++) {
            $count = $this->M_Logistik_farmasi->countRiwayatPermintaan($page_data[$i]->id_req);
            if($count>0){
                $no = $i + 1;
                $button = "<div class='btn btn-success btn-icon-anim btn-square' onclick='tampilDetailRequest(\"".$page_data[$i]->id_req."\")'><i class='icon-rocket'></i></div>";
                $nama = $page_data[$i]->nama;
                $tipe = $page_data[$i]->tipe;
                $time = strtotime($page_data[$i]->tanggal);
                $tgl = strftime("%A, %d %B %Y", $time);
                $waktu = strftime("%H:%M WIB", $time);
                $out[$i] = array($no, $button, $tgl, $waktu, $tipe, $nama);
            }
            
        }

        if ($out == null) {
            echo '{"data":""}';
            exit;
        } else {
            $page_data['data'] = $out;
            echo json_encode($page_data);
            exit;
        }
    }
    public function Tampil_Range_riwayat_permintaan()
    {

        $mulai = $this->input->post('mulai');
        $akhir = $this->input->post('akhir');

        $page_data = $this->M_Logistik_farmasi->selectRangeRiwayatPermintaanObat($mulai, $akhir);
        
        $out = null;
        for ($i = 0; $i < count($page_data); $i++) {
            $count = $this->M_Logistik_farmasi->countRiwayatPermintaan($page_data[$i]->id_req);
            if($count>0){
                $no = $i + 1;
                $button = "<div class='btn btn-success btn-icon-anim btn-square' onclick='tampilDetailRequest(\"".$page_data[$i]->id_req."\")'><i class='icon-rocket'></i></div>";
                $nama = $page_data[$i]->nama;
                $tipe = $page_data[$i]->tipe;
                $time = strtotime($page_data[$i]->tanggal);
                $tgl = strftime("%A, %d %B %Y", $time);
                $waktu = strftime("%H:%M WIB", $time);
                $out[$i] = array($no, $button, $tgl, $waktu, $tipe, $nama);
            }
            
        }

        if ($out == null) {
            echo '{"data":""}';
            exit;
        } else {
            $page_data['data'] = $out;
            echo json_encode($page_data);
            exit;
        }
    }
    public function Tampil_list_riwayat_permintaan_obat()
    {
        $id_req = $this->input->post('id_req');
        $page_data = $this->M_Logistik_farmasi->getListRiwayatPermintaanObat($id_req);
        
        $out = null;
        for ($i = 0; $i < count($page_data); $i++) {

            $no = $i + 1;
            $nama = $page_data[$i]->nama;
            $tgl_exp = $page_data[$i]->tgl_exp;
            $jml_req = $page_data[$i]->jml_req;
            $jml_terima = $page_data[$i]->jml_terima;
            $getStok = $this->M_Logistik_farmasi->getStokByRiwayatPermintaan($page_data[$i]->tgl_exp, $page_data[$i]->id_logistik)->stok;
            $stok = number_format($getStok);
            if($page_data[$i]->status =="DIAJUKAN"){
                $status= "<span class='label label-info'>DIAJUKAN</span>";
            }else if($page_data[$i]->status =="DITOLAK"){
                $status= "<span class='label label-danger'>DITOLAK</span>";
            }else if($page_data[$i]->status =="DITERIMA"){
                $status= "<span class='label label-success'>DITERIMA</span>";
            }
            $keterangan = $page_data[$i]->keterangan;
            if($page_data[$i]->status !="DIAJUKAN" || $getStok < $page_data[$i]->jml_req){
                $terima = "-";
            }else{
                $terima = "<div class='btn btn-success btn-icon-anim btn-square' onclick='terimaLangsung(\"".$page_data[$i]->id_req. "\",\"".$page_data[$i]->tipe."\",\"".$page_data[$i]->id_logistik. "\" )'><i class='icon-like '></i></div>";
            }
            if($page_data[$i]->status !="DIAJUKAN"){
                $respon = "-";
            }else{
                $respon = "<div class='btn btn-warning btn-icon-anim btn-square' 
                onclick='tampilKonfirmasi(\"".$page_data[$i]->id_req. "\",\"".$page_data[$i]->tipe. "\",\"".$page_data[$i]->id_logistik."\",\"".$page_data[$i]->id_staff. "\" )'>
                <i class='icon-hourglass '></i></div>";
            }
            
            $out[$i] = array($no, $nama, $tgl_exp, $jml_req, $jml_terima, $stok, $status,$keterangan, $terima, $respon);
        }

        if ($out == null) {
            echo '{"data":""}';
            exit;
        } else {
            $page_data['data'] = $out;
            echo json_encode($page_data);
            exit;
        }
    }
    public function updateTerimaStokLogistik()
    {
        $data_staff = $this->session->userdata('data_auth');
        $id_request = $this->input->post('id_request');
        $perequest = $this->input->post('perequest');
        $idLogistik = $this->input->post('idLogistik');
        $now = new DateTime();
        $update = array(
            'status' => 'DITERIMA',
            'jml_terima' => $this->input->post('jml_terima'),
            'tgl_res' => $now->format('Y-m-d H:i:s'),
            'keterangan' => $this->input->post('keterangan'),
        );
        $this->M_Logistik_farmasi->update_detail_request($id_request, $update);

        $stok_logistik = array(
            'id_stok' => uniqid(),
            'id_logistik' => $idLogistik,
            'tgl' => $now->format('Y-m-d H:i:s'),
            'keterangan' => 'MUTASI',
            'frek' => $this->input->post('jml_terima')*-1,
            'kadaluarsa' => $this->input->post('tgl_exp'),
            'asal_tujuan' => $perequest,
            'id_struk' => $id_request,
            'id_staff' => $data_staff->id_staff,
        );
        $this->M_Logistik_farmasi->insertStok($stok_logistik, 'stok_logistik');
        $out['status'] = "success";

        if($perequest == "apotik"){
            $stok_perequest = array(
                'id_stok' => uniqid(),
                'id_logistik' => $idLogistik,
                'tgl' => $now->format('Y-m-d H:i:s'),
                'keterangan' => 'MUTASI',
                'frek' => $this->input->post('jml_terima'),
                'kadaluarsa' => $this->input->post('tgl_exp'),
                'asal_tujuan' => 'Logistik',
                'id_req' => $id_request,
                'id_staff' => $data_staff->id_staff,
            );
            $this->M_Logistik_farmasi->insertStok($stok_perequest, 'stok_apotik');
            $out['status'] = "success";
            
        }else if($perequest == "igdapotik"){
            
            $stok_perequest = array(
                'id_stok' => uniqid(),
                'id_logistik' => $idLogistik,
                'tgl' => $now->format('Y-m-d H:i:s'),
                'keterangan' => 'MUTASI',
                'frek' => $this->input->post('jml_terima'),
                'kadaluarsa' => $this->input->post('tgl_exp'),
                'asal_tujuan' => 'Logistik',
                'id_req' => $id_request,
                'id_staff' => $data_staff->id_staff,
            );
            $this->M_Logistik_farmasi->insertStok($stok_perequest, 'stok_igd');
            $out['status'] = "success";
            
        }else if($perequest == "ok"){
            $stok_perequest = array(
                'id_stok' => uniqid(),
                'id_logistik' => $idLogistik,
                'tgl' => $now->format('Y-m-d H:i:s'),
                'keterangan' => 'MUTASI',
                'frek' => $this->input->post('jml_terima'),
                'kadaluarsa' => $this->input->post('tgl_exp'),
                'asal_tujuan' => 'Logistik',
                'id_req' => $id_request,
                'id_staff' => $data_staff->id_staff,
            );
            $this->M_Logistik_farmasi->insertStok($stok_perequest, 'stok_ok');
            $out['status'] = "success";
           
        }
        $out['status'] = "success";
        echo json_encode($out);
    }
    public function updateTolakStokLogistik()
    {
        $id_request = $this->input->post('id_request');
        $now = new DateTime();
        $update = array(
            'status' => 'DITOLAK',
            'jml_terima' => 0,
            'tgl_res' => $now->format('Y-m-d H:i:s'),
            'keterangan' => $this->input->post('keterangan'),
        );
        $this->M_Logistik_farmasi->update_detail_request($id_request, $update);
        
        $out['status'] = "success";
        echo json_encode($out);
    }
}